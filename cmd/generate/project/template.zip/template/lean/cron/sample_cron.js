// Schedule explanation

// - Second
// - Minute
// - Hour
// - Day of the month (1-31)
// - Month (1-12)
// - Day of the week (0-6)

schedule = "0 0 0 1 1 *"

function run(){
    // do something here
}
