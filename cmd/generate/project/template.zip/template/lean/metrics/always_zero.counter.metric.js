description = "my metric"

function collect() {
    return 0
}